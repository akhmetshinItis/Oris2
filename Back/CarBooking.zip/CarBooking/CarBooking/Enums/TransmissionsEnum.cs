namespace CarBooking.Enums ;

    public enum TransmissionsEnum
    {
        Manual, 
        Automatic,
    }