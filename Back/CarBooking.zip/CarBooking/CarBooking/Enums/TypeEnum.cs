namespace CarBooking.Enums ;

    public enum TypeEnum
    {
        Suv,
        Supercar,
        Usual,
    }