using CarBooking.DataSeeds;
using CarBooking.Models;
using Microsoft.AspNetCore.Mvc;

namespace CarBooking ;

    [ApiController]
    public class CarsController : ControllerBase
    {
        public CarsController()
        {
        }

        [HttpGet("api/cars")]
        public CarModel? Get([FromRoute] int id)
            => Seed.CarModels.FirstOrDefault(x => x.Id == id);
    }